#include <random>
#include "../../board/board.h"

void resetSeed ();
void initRandomKeys ();

U64 generateHashKey (Board* board);
